from setuptools import setup, find_packages

setup(
    name='YourPackageName',
    version='0.1',
    packages=find_packages(),
    long_description=open('README.md').read(),
)
